package edu.uoc.uocanoid.view;

import edu.uoc.uocanoid.UOCanoid;
import javafx.fxml.FXML;

import java.io.IOException;

/**
 * CreditsViewController class related to "credits.fxml".
 *
 * @author David García Solórzano
 * @version 1.0
 */
public class CreditsViewController {


}
